# WEBSITE

**BMSCE CAMPUS EXAM APPLICATION PORTAL**

# Updates that need to be included

- You only need usn and password for login of the student
- Define functionality to add profile picture of the student
- Send a copy of application to student email id
- Find the api that will fetch you dynamic data of results
- change the form layout
  - use fildset  
